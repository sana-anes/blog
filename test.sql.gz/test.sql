-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 17, 2020 at 10:37 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE test;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `creatorname` varchar(255) NOT NULL,
  `datetime` date NOT NULL,
  PRIMARY KEY (`category_id`)
) ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `name`, `creatorname`, `datetime`) VALUES
(1, 'food', 'user', '2020-08-26'),
(2, 'lifestyle', 'user', '2020-08-13'),
(4, 'health', 'user', '2020-08-14'),
(6, 'work', 'user', '2020-08-14'),
(8, 'travel', 'user', '2020-08-14');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `datetime` date NOT NULL,
  PRIMARY KEY (`comment_id`)
) ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `post_id`, `name`, `email`, `comment`, `datetime`) VALUES
(6, 3, 'sana anes', '', 'best season ever <3', '2020-08-14'),
(7, 3, 'sana', 'sana@gmail.com', 'hello', '2020-08-17'),
(8, 7, 'nabil_anes', 'nabil@gmail.com', 'good tips ', '2020-08-17');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `post_id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `category` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `owner_id` int(10) NOT NULL,
  `datetime` date NOT NULL,
  PRIMARY KEY (`post_id`)
) ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `title`, `image`, `content`, `category`, `author`, `owner_id`, `datetime`) VALUES
(3, 'This Is A Standard Format Post\r\n', 'image.jpg', 'We’re in the thick of it, the best months of Summer! Summer is the perfect time to recharge your batteries, get some sun, and take it easy.\r\nTo celebrate the joys of the season and the many fun activities awaiting us, we’ve put together a fun Summertime gallery from of our favorite Flickr photographers. Shut out the noise, stop, and take a minute to smell the flowers.', 'lifestype', 'Leticia Roncero', 1, '2020-08-06'),
(4, 'delicious food', 'food1.jpg', '                                                    Electrolytes are minerals that carry an electrical charge. Theyâ€™re vital for health and survival. Electrolytes spark cell function throughout the body.\r\n\r\nThey support hydration and help the body produce energy. Theyâ€™re also responsible for stimulating muscle contractions, including those that keep your heart beating.\r\n\r\nPrepared foods contain some types of electrolytes. So do certain whole foods, such as spinach, turkey, and oranges.\r\n\r\n                                                ', 'food', 'user', 1, '2020-08-17'),
(5, 'easy recipes', 'food.jpg', 'Combine 250g lean beef mince with 2 slices white bread, whizzed into breadcrumbs, 1 chopped small onion and some salt and pepper. Shape into meatballs. Use as directed in the recipe or make double and freeze some for later.', 'food', 'user', 1, '2020-08-17'),
(6, 'How to Find the Best Skincare Routine, According to a Dermatologist', 'skin.jpg', 'Below, Dr. Magovern offers a basic step-by-step skincare routine to use as a blueprint for your own regimen, with product recommendations tested by the GH Beauty Lab.', 'health', 'sana_anes', 2, '2020-08-17'),
(7, 'Tips for Exploring Greece on A Budget uptaded', 'greece.jpg', '                                                                                                        If you have the flexibility of time, the best way to fly to Greece on a budget is during the off-season. If you are flying from Asia, consider budget carrier Scoot which flies directly from Singapore to Athens. Greece is insanely popular during summer months from June right up to August. During this period, prices for accommodation, food and even ferry tickets see a steady 20â€“50% hike. \r\n\r\nf you are available to travel on other months, consider going in May or September. This is ideal if you still wish to enjoy summer minus the ludicrous prices. Another alternative would be to travel during the shoulder season in October right up to early November when temperatures are a lot cooler.                                                                                                ', 'travel', 'nabil_anes', 4, '2020-08-17');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`) VALUES
(1, 'user', 'user', 'user@gmail.com'),
(2, 'sana_anes', '0000', 'sana@gmail.com'),
(4, 'nabil_anes', '0000', 'nabil@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
